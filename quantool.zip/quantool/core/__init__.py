# This file makes the 'core' directory a Python sub-package.
# It can be left empty.
